
const Stripe = require("stripe");

exports.handler = async (event) => {
  if (!process.env.STRIPE_SECRET_KEY || !process.env.STRIPE_WEBHOOK_SECRET) {
    return { statusCode: 500, body: "Stripe webhook is not configured." };
  }

  const stripe = new Stripe(process.env.STRIPE_SECRET_KEY);
  const sig = event.headers["stripe-signature"];

  try {
    const stripeEvent = stripe.webhooks.constructEvent(
      event.body,
      sig,
      process.env.STRIPE_WEBHOOK_SECRET
    );

    if (stripeEvent.type === "checkout.session.completed") {
      const session = stripeEvent.data.object;
      console.log("PAID BIG PAPA ORDER", {
        id: session.id,
        reference: session.metadata && session.metadata.order_reference,
        type: session.metadata && session.metadata.order_type,
        name: session.metadata && session.metadata.customer_name,
        phone: session.metadata && session.metadata.phone,
        requested_time: session.metadata && session.metadata.requested_time,
        address: session.metadata && session.metadata.address,
        notes: session.metadata && session.metadata.notes,
        amount_total: session.amount_total,
        currency: session.currency,
        payment_status: session.payment_status
      });
    }

    return { statusCode: 200, body: JSON.stringify({ received: true }) };
  } catch (err) {
    console.error(err);
    return { statusCode: 400, body: `Webhook Error: ${err.message}` };
  }
};
