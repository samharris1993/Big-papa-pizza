
const Stripe = require("stripe");

exports.handler = async (event) => {
  if (!process.env.STRIPE_SECRET_KEY) {
    return { statusCode: 500, body: JSON.stringify({ error: "Stripe is not configured." }) };
  }

  const sessionId = event.queryStringParameters && event.queryStringParameters.session_id;
  if (!sessionId) {
    return { statusCode: 400, body: JSON.stringify({ error: "Missing session_id" }) };
  }

  try {
    const stripe = new Stripe(process.env.STRIPE_SECRET_KEY);
    const session = await stripe.checkout.sessions.retrieve(sessionId, {
      expand: ["line_items"]
    });

    return {
      statusCode: 200,
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        paid: session.payment_status === "paid",
        status: session.status,
        customer_email: session.customer_details && session.customer_details.email,
        customer_name: session.metadata && session.metadata.customer_name,
        order_reference: session.metadata && session.metadata.order_reference,
        order_type: session.metadata && session.metadata.order_type,
        requested_time: session.metadata && session.metadata.requested_time,
        amount_total: session.amount_total,
        currency: session.currency,
        items: (session.line_items && session.line_items.data || []).map(x => ({
          description: x.description,
          quantity: x.quantity,
          amount_total: x.amount_total
        }))
      })
    };
  } catch (err) {
    console.error(err);
    return {
      statusCode: 400,
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ error: "Could not load payment." })
    };
  }
};
