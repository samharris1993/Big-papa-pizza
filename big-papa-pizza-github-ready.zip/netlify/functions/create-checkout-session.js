
const Stripe = require("stripe");

const MENU = {
  "1": { name: "Margarita", unit_amount: 995 },
  "2": { name: "Pepperoni", unit_amount: 1095 },
  "3": { name: "Pepperoni Crumble", unit_amount: 1095 },
  "4": { name: "Pepper-Honey", unit_amount: 1195 },
  "5": { name: "Hot Honey", unit_amount: 1095 },
  "6": { name: "Big Papas Fully Loaded", unit_amount: 1395 }
};

exports.handler = async (event) => {
  if (event.httpMethod !== "POST") {
    return { statusCode: 405, body: "Method not allowed" };
  }

  if (!process.env.STRIPE_SECRET_KEY) {
    return {
      statusCode: 500,
      body: JSON.stringify({ error: "Stripe is not configured on this site." })
    };
  }

  try {
    const stripe = new Stripe(process.env.STRIPE_SECRET_KEY);
    const body = JSON.parse(event.body || "{}");

    const items = Array.isArray(body.items) ? body.items : [];
    if (!items.length) {
      return { statusCode: 400, body: JSON.stringify({ error: "Your cart is empty." }) };
    }

    const line_items = items.map(item => {
      const product = MENU[String(item.id)];
      const qty = Math.max(1, Math.min(20, Number(item.qty) || 1));
      if (!product) throw new Error("Unknown menu item");

      return {
        quantity: qty,
        price_data: {
          currency: "gbp",
          unit_amount: product.unit_amount,
          product_data: {
            name: product.name,
            description: "Big Papa Pizza"
          }
        }
      };
    });

    const orderType = body.orderType === "Delivery" ? "Delivery" : "Collection";
    const orderRef = body.orderRef || `BP${Date.now().toString().slice(-6)}`;
    const origin =
      process.env.URL ||
      process.env.DEPLOY_PRIME_URL ||
      process.env.DEPLOY_URL ||
      "http://localhost:8888";

    const metadata = {
      order_reference: String(orderRef).slice(0, 500),
      order_type: String(orderType).slice(0, 500),
      customer_name: String(body.name || "").slice(0, 500),
      phone: String(body.phone || "").slice(0, 500),
      requested_time: String(body.requestedTime || "ASAP").slice(0, 500),
      address: String(body.address || (orderType === "Collection" ? "Collection" : "")).slice(0, 500),
      notes: String(body.notes || "None").slice(0, 500)
    };

    const session = await stripe.checkout.sessions.create({
      mode: "payment",
      line_items,
      customer_email: body.email || undefined,
      phone_number_collection: { enabled: true },
      metadata,
      payment_intent_data: { metadata },
      success_url: `${origin}/success.html?session_id={CHECKOUT_SESSION_ID}`,
      cancel_url: `${origin}/?payment=cancelled`,
      allow_promotion_codes: false
    });

    return {
      statusCode: 200,
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ url: session.url })
    };
  } catch (err) {
    console.error(err);
    return {
      statusCode: 400,
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ error: err.message || "Could not start payment." })
    };
  }
};
